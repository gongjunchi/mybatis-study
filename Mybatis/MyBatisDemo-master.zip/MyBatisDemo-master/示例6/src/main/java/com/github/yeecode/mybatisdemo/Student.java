package com.github.yeecode.mybatisdemo;

public class Student extends User<Number> {

}
