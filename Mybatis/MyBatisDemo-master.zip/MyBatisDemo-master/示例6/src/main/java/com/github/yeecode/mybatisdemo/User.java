package com.github.yeecode.mybatisdemo;

import java.util.List;

public class User<T> {
    public List<T> getInfo() {
        return null;
    }
}
