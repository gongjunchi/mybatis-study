package com.github.yeecode.mybatisdemo;

public interface Phone {
    String callIn();
    Boolean callOut(String info);
}
