package com.github.yeecode.mybatisdemo.model;

public interface UserInterface {
    String sayHello(String name);
}
