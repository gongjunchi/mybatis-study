package com.github.yeecode.mybatisdemo.model;

public class User {
    public String sayHello(String name) {
        System.out.println("hello " + name);
        return "OK";
    }
}
